

    <head>
       
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="css/homepage.css">
   
    </head>


<section class="index">
<?php 
include "layout/cabecalho.php";
 ?>
 
 <body>

<div class="corpo">
<div class="presentation">Bem-vindo ao DrawCV</div>	
<div class="conteudo">Crie seu curriculum de uma forma simples e profissional</div>
<div class="buttom">	
<button name="Criar CV"><a href="/GeradorCV/contatos.php">Criar CV</a></button>
</div>

</div>
<?php 
include "layout/rodape.php"; 

?>

</section>
</body>