<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>DrawCV</title>


</head>
<body>

<div class="cabecalho">
		<div class="logo">
	<img  height="170" src="img/Drawcv-logo.png" alt="Drawcv-logo">
		</div>
	</div>

		
		
	</body>
	
</html>
