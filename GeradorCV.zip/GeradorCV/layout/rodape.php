<div class="rodape">
	<img src="img/flag-of-cuba-and.jpg" width="20px" >
	<span>Brasil-Cuba</span>
	
</div>